<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Success</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background-color: rgb(19, 3, 84);
        }

        .container {
            text-align: center;
            color: white;
            padding: 20px;
        }

        img {
            border-radius: 50%;
        }
    </style>
</head>
<body>
    <center>
        <div class="container">
            <img src="OIP.jpg" alt="Success Image">
            <h2>Opps Error Occured !</h2>
            <h4><p>Can't Find Your Record To Save Your Entry </p></h4>
        </div>
    </center>
</body>
</html>


